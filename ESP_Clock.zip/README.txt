                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1134525
ESP Clock by tamberg is licensed under the Creative Commons - Attribution - Share Alike license.
http://creativecommons.org/licenses/by-sa/3.0/

# Summary

Built by [@tamberg](https://twitter.com/tamberg) during http://bilbaomakerfaire.com/meet-the-makers-2015/

Pictures https://www.flickr.com/photos/tamberg/albums/72157661456853951

Video of how it works https://www.flickr.com/photos/tamberg/22978920380

Made from 12 [ESP8266](http://www.esp8266.com/). Each slice controls 5 minutes, plus a certain hour.

Slices independently get the time from the Web, then display their part.

Setup is simplified through a D-Link DIR-505 repeater / access point.

Note that ESP is also the ISO [three-letter country code](https://en.wikipedia.org/wiki/ISO_3166-1_alpha-3) for Spain.

# How I Designed This

## Material

12 ESP8266 (e.g. https://www.adafruit.com/product/2471)
1 FTDI programmer (e.g. https://www.adafruit.com/products/284)
12 8mm Neopixel (e.g. https://www.adafruit.com/products/1734)
60 Neopixel strip (e.g. https://www.adafruit.com/products/1461)
Big red button (e.g. https://www.adafruit.com/products/1185)
1 D-Link DIR-505 (change WiFi location without reprogramming)
3mm Acrylic, min. 40 x 40 cm
1 empty filament spool
F-M jumper wires
5mm power wire
220V power cord with plug
220V to 5V / 3.5A power adapter
Random PCB from Pusterla (or DIY)
Small zip ties
Duct tape
Hot glue

## Tools

Soldering iron
Hot glue gun
Scissors
Pliers


## Code

https://bitbucket.org/tamberg/espclock/src/tip/ESPClock/ESPClock.ino

## Hype

http://hackaday.com/2015/11/26/absurd-overuse-of-esp8266-in-a-clock